# placement_system 

### server.js file 
i have added the server.js file for frontend people to test their api endpoints and get preview of web pages  


### these files have verified names for keys of get and post requests 
- student_pages/resume_page 

efwefwef
